#!/bin/sh
chmod -R +x misc/upgrade_scripts
node pi-upgrade.js

#!/bin/bash
HOSTNAME=$(id -un)

echo "Changing Dispaly Settings"
sudo sed 's/.*disable_overscan.*/disable_overscan=1/' -i /boot/config.txt
sudo sed 's/.*hdmi_force_hotplug.*/hdmi_force_hotplug=1/' -i /boot/config.txt
sudo sed 's/.*hdmi_group.*/hdmi_group=1/' -i /boot/config.txt
sudo sed 's/.*hdmi_mode.*/hdmi_mode=4/' -i /boot/config.txt
sudo sed 's/.*hdmi_drive.*/hdmi_drive=2/' -i /boot/config.txt

sudo sed -i -e 's/.*overscan_left.*/overscan_left=40/' -e 's/.*overscan_right.*/overscan_right=40/' -e 's/.*overscan_top.*/overscan_top=20/' -e 's/.*overscan_bottom.*/overscan_bottom=20/' -e 's/.*framebuffer_width.*/framebuffer_width=1280/' -e 's/.*framebuffer_height.*/framebuffer_height=720/'  /boot/config.txt

sudo sed -i 's/.*XKBLAYOUT=.*/XKBLAYOUT="us"/' /etc/default/keyboard

sudo sed -i 's/.*display_rotate.*/display_rotate=0/' /boot/config.txt

echo "Changing Network Interface"
sudo rm -rf /etc/network/interface
sudo cp /home/pi/piimage/misc/interfaces /etc/network/interfaces


echo "Remove Identity File"
sudo rm -rf  /home/pi/piimage/config/_settings.json
sudo rm -rf  /home/pi/piimage/config/_config.json
echo 'pi:$apr1$G4yYdggH$aqJwlrg6yXYERl4DCZ2DT1' > /home/pi/piimage/htpasswd

echo "Change HOSTNAME"
if [ $HOSTNAME == "raspberrypi" ]
then
	echo "NO change to user"
else
	echo "change user"
	HOSTNAME="raspberrypi"
	sudo /bin/bash /home/pi/piimage/misc/change-hostname.sh $HOSTNAME
fi
sudo /bin/bash /home/pi/piimage/misc/networkchange.sh "8.8.4.4" "8.8.8.8"
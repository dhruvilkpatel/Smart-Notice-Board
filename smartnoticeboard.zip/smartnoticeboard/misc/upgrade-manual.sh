#!/bin/sh
cd /home/pi

if [ -z $1 ]; then
    echo "Please copy the image zip file to /home/pi folder and provide the image file name"
    exit 1
fi
if [ ! -f "$1" ]
then
    echo "The image file does not exist"
    exit 1
fi


echo "check .problem directory"
if [ -d "/home/pi/piimage.problem" ]; then
	echo "directory exist"
	sudo rm -rf  /home/pi/piimage.problem
else
	echo "directory does not exist"
fi

echo "installing new version of software from $1"

# kill forever process
sudo pkill -f forever
sudo pkill -f node
sudo pkill -f uzbl
sudo pkill -f omx
sudo fbi -T 1 ~/piupdate.png &

echo "saving the current image"
sudo rm -rf  ~/piimage.prev
mv ~/piimage ~/piimage.prev

echo "unzipping the New pi image"
unzip $1
mv ~/piImage ~/piimage

echo "copying configuration files"
cp ~/piimage.prev/config/_config.json ~/piimage/config
cp ~/piimage.prev/config/_settings.json ~/piimage/config

echo "copying the previous node modules"
cp -R ~/piimage.prev/node_modules ~/piimage

cd ~/piimage

chmod +x misc/upgrade.sh
chmod +x misc/upgrade-manual.sh
chmod +x misc/downgrade.sh
chmod +x misc/network-config
chmod -R +x misc/upgrade_scripts

echo "installing npm packages"
npm install
echo "adding line in socket.io npm"
sed "s/.*self\.transport\.onClose.*/if \(self\.transport\) self\.transport\.onClose\(\)/" -i ~/piimage/node_modules/socket.io-client/lib/socket.js

file="pi-upgrade.js"
if [ -f "$file" ]
then
	node $file
fi

sync

rm ~/piimage/misc/install.sh ~/piimage/misc/autostart

sudo reboot
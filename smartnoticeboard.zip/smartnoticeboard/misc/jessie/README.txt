- Do not remove  `gdb` , `gcc`  application

- Change lxde-rc file to lxde-pi-rc

- Change   ~/.config/lxpanel/LXDE/panels/panel  to   ~/.config/lxpanel/LXDE-pi/panels/panel

- Start up video (welcome video) is absent. 
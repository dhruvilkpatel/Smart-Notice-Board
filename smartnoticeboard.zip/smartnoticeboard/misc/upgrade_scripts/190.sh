#!/usr/bin/env bash

echo "change omx.py"
sudo rm -rf /home/pi/omx.py
cp /home/pi/piimage/misc/omx.py /home/pi/
sudo chmod 755 /home/pi/omx.py

CHECK_LINE_EXIST=`cat /home/pi/start.sh | grep "sudo pkill omxplayer"`

if [  -z "$CHECK_LINE_EXIST" ]
then
    sudo sed -i '/node pi-monitor.js/ a\sleep 10 \nsudo kill \ $(pidof python omx.py) \nsudo pkill omxplayer' /home/pi/start.sh
fi

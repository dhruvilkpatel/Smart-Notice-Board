#!/usr/bin/env bash
cd /home/pi/piimage/misc
sudo rm -rf /usr/bin/network-config
sudo ln -s /home/pi/piimage/misc/network-config /usr/bin/network-config
sudo chmod +x /home/pi/piimage/misc/network-config
sudo chmod +x  /usr/bin/network-config

sudo sed -i 's/.*http.get(API_VIDEO_INFO, params=params.*/\tres = http.get(API_VIDEO_INFO, params=params , headers=HLS_HEADERS)/' /usr/local/lib/python2.7/dist-packages/livestreamer/plugins/youtube.py

sudo apt-get -y install build-essential

cd /home/pi/piimage/tools/screenshot
chmod +x make.sh
./make.sh

cd /home/pi/piimage/tools/uzbl
chmod +x make.sh
./make.sh

echo "gtk css"
if [ -d "/home/pi/.config/gtk-3.0" ];then
    sudo rm -rf /home/pi/.config/gtk-3.0/gtk.css
    sudo cp /home/pi/piimage/misc/gtk.css /home/pi/.config/gtk-3.0/
    sudo chmod +x /home/pi/.config/gtk-3.0/gtk.css
fi
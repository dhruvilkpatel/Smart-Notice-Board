#!/usr/bin/env bash

echo "OpenVG update"

cd /home/pi/piimage/tools/openvg_display
chmod +x make.sh
./make.sh

echo "Youtube DL"
sudo pip install --upgrade youtube-dl

echo "Xdotool"
sudo apt-get -y install xdotool

sudo cp /home/pi/piimage/misc/piimage-import.service /etc/systemd/system/
sudo systemctl enable piimage-import.service

sudo cp /home/pi/piimage/misc/40-piimage-import.rules /etc/udev/rules.d/
sudo udevadm control --reload

chmod +x /home/pi/piimage/misc/import-assets.sh

cd /home/pi/
echo "MPV"
if [ $(getconf _NPROCESSORS_ONLN) -eq 4 ]; then
    wget https://s3.amazonaws.com/piimage/assets/binaries/mpv_0.27.2_armhf.deb
    #wget https://s3.amazonaws.com/piimage/assets/binaries/mpv_0.29.1_armhf.deb
    sudo apt-get update
    sudo apt install -y ./mpv_*.deb
    sudo apt-get update
    sudo apt install -f
    sudo apt install -y ./mpv_*.deb          
fi


#!/usr/bin/env bash

rm -rf /home/pi/omx.py
cp /home/pi/piimage/misc/omx.py /home/pi/
sudo chmod 755 /home/pi/omx.py
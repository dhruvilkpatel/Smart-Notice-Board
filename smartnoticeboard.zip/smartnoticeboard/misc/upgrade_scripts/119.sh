#!/usr/bin/env bash
#upgrade script for version 1.1.9
#script to append a flag in start.sh
sed -i '/pi-monitor.js/ i\export WEBKIT_DISABLE_TBS=1' /home/pi/start.sh
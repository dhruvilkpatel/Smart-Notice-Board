#!/usr/bin/env bash

mkdir /home/pi/piimage-data
echo "#!/usr/bin/env bash" > /home/pi/piimage-data/upgrade.sh

cd /home/pi/
wget https://s3.amazonaws.com/piimage/assets/piimage/update.png

echo "Youtube DL"
sudo pip install --upgrade youtube-dl


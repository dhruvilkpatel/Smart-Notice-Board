#!/bin/bash

LINEPRESENT=`grep "sleep" /home/pi/start.sh `
if [ -z "$LINEPRESENT" ];then
	echo "add line to start.sh"
	echo "sleep infinity" >> /home/pi/start.sh
fi

echo " Screenshot modification "
EXECUTABLE="/home/pi/piimage/tools/screenshot/screenshot"

if [ ! -f "$EXECUTABLE" ];then
	echo "screen shot excutable not found, Install New"
	cd /home/pi/piimage/tools/screenshot
	sudo rm -rf /usr/local/bin/screenshot
	chmod +x make.sh
	./make.sh
else
	echo "executable file present"
fi

echo "image view"
cd /home/pi/piimage/tools/pngview
chmod +x make.sh
./make.sh

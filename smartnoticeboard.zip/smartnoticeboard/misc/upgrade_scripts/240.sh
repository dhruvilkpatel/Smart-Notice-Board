#!/usr/bin/env bash

echo "OpenVG ticker length"
cd /home/pi/piimage/tools/openvg_display
chmod +x make.sh
./make.sh

echo "Screenshot portrait"
cd /home/pi/piimage/tools/screenshot
chmod +x make.sh
./make.sh


echo "Youtube DL"
sudo pip install --upgrade youtube-dl


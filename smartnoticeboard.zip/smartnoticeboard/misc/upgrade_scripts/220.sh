#!/usr/bin/env bash

cd /home/pi/piimage/tools/openvg_display
chmod +x make.sh
./make.sh

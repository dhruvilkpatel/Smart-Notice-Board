
#!/usr/bin/env bash
# remove and replace old network-config 
sudo rm -rf /usr/bin/network-config
sudo cp /home/pi/piimage/misc/network-config /usr/bin/
sudo chmod +x /usr/bin/network-config
#!/usr/bin/env bash
echo "Remove old brand video"
rm -rf /home/pi/brand_piimage.mp4

echo "Update omx.py script"
rm -rf /home/pi/omx.py
cp /home/pi/piimage/misc/omx.py /home/pi/
sudo chmod +x /home/pi/omx.py

echo "add wifi repair"
sudo apt-get -y install ifupdown libwebpdemux1

echo "remove old update png file"
rm -rf /home/pi/piupdate.png

echo " Get new Brand videos"
cd /home/pi/
wget https://s3.amazonaws.com/piimage/assets/brand_piimage_portrait.mp4
wget https://s3.amazonaws.com/piimage/assets/brand_piimage_landscape.mp4
wget https://s3.amazonaws.com/piimage/assets/update_portrait.mp4
wget https://s3.amazonaws.com/piimage/assets/update_landscape.mp4

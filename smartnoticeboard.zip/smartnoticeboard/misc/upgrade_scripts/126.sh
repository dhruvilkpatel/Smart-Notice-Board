#!/usr/bin/env bash

echo "adding line in socket.io npm"
sed "s/.*self\.transport\.onClose.*/if \(self\.transport\) self\.transport\.onClose\(\)/" -i /home/pi/piimage/node_modules/socket.io-client/lib/socket.js


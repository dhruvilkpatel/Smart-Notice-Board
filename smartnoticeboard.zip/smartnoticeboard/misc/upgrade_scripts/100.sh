#!/bin/bash


echo "release specific commands 0.8.9"

sudo sed 's/.*disable_overscan.*/disable_overscan=1/' -i /boot/config.txt
sudo sed -i '$a\overscan_scale=1' /boot/config.txt
sudo sed -i -e 's/.*overscan_left.*/overscan_left=40/' -e 's/.*overscan_right.*/overscan_right=40/' -e 's/.*overscan_top.*/overscan_top=20/' -e 's/.*overscan_bottom.*/overscan_bottom=20/' -e 's/.*framebuffer_width.*/framebuffer_width=1280/' -e 's/.*framebuffer_height.*/framebuffer_height=720/'  /boot/config.txt

sudo mv /boot/cmdline.txt /boot/cmdline.txt.bak
sudo cp ~/piimage/misc/wheezy/cmdline.txt /boot/cmdline.txt
sudo cp ~/piimage/misc/wheezy/pifstab /etc/fstab
sudo sed -i 's/.*#FSCKFIX.*/FSCKFIX=yes/' /etc/default/rcS

sudo mv /etc/rc.local /etc/rc.local.old
sudo mv /home/pi/piimage/misc/wheezy/rc.local /etc/
sudo chmod 755 /etc/rc.local

sudo mv /etc/init.d/asplashscreen /etc/init.d/newwelcome
sudo chmod a+x /etc/init.d/newwelcome
sudo insserv /etc/init.d/newwelcome

sudo apt-get -y install  host ethtool nmap

mkdir -p /home/pi/logs
chmod -R 777 /home/pi/logs

if grep -q "bash_profile" "/home/pi/start.sh"
then
    echo "bash_profile already added"
else
    echo "adding .bash_profile"
    sudo sed -i '/node pi-monitor.js/ i\ \n. /home/pi/.bash_profile\n' /home/pi/start.sh
fi



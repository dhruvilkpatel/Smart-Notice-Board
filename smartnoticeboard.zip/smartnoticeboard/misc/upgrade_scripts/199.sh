#!/usr/bin/env bash

if grep -q "iface wlan0 inet static"  /etc/network/interfaces; then
    sudo sed -i 's/.*denyinterfaces wlan0*./denyinterfaces wlan0/' /etc/dhcpcd.conf
fi

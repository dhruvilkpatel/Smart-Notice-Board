#!/bin/sh

pkill -f forever
pkill -f node
pkill -f uzbl
pkill -f omx

cd ~

echo "rolling back to previous release"

if [ -d "/home/pi/piimage.prev" ]
then
    rm -rf  ~/piimage.problem
    mv  ~/piimage  ~/piimage.problem
    cp -a  ~/piimage.prev/  ~/piimage
    sync
    sudo reboot
fi


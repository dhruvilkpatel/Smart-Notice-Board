#!/bin/bash
# This script will be called by install.sh

echo "*******************************************************************************************************************************************"
echo "This method is not supported since Jessie, please use the piimage image at https://github.com/colloqi/piimage/blob/master/README.md#method-1-download-image-and-prepare-the-sd-card"
echo "*******************************************************************************************************************************************"
return 0

notify(){
    printf "\n"
    figlet -f digital -c $1
    printf "\n"
}

wheezySetup(){
    notify "startup script"
    cp /home/pi/piimage/misc/wheezy/start.sh /home/pi/
    sed -i '/sudo raspi-config --expand-rootfs/s/^/#/' /home/pi/start.sh
    cp /home/pi/piimage/misc/omx.py /home/pi

    notify "modify X"
    [ -f /home/pi/.config/openbox/lxde-rc.xml ] && mv /home/pi/.config/openbox/lxde-rc.xml /home/pi/.config/openbox/lxde-rc.xml.bak
    [ -d /home/pi/.config/openbox ] || mkdir -p /home/pi/.config/openbox
    ln -s /home/pi/piimage/misc/wheezy/lxde-rc.xml /home/pi/.config/openbox/lxde-rc.xml
    [ -f /home/pi/.config/lxpanel/LXDE/panels/panel ] && mv /home/pi/.config/lxpanel/LXDE/panels/panel /home/pi/.config/lxpanel/LXDE/panels/panel.bak
    sudo sed -e 's/^#xserver-command=X$/xserver-command=X -nocursor -s 0 dpms/g' -i /etc/lightdm/lightdm.conf

    notify "LXDE settings"
    sudo mv /etc/xdg/lxsession/LXDE/autostart /etc/xdg/lxsession/LXDE/autostart.bak
    sudo cp /home/pi/piimage/misc/wheezy/autostart /etc/xdg/lxsession/LXDE/
    sudo chmod +x  /etc/xdg/lxsession/LXDE/autostart

    notify "quiet boot"
    sudo cp /boot/cmdline.txt /boot/cmdline.txt.bak
    sudo cp /home/pi/piimage/misc/wheezy/cmdline.txt /boot/cmdline.txt

    notify "Welcome video"
    sudo cp /home/pi/piimage/misc/wheezy/newwelcome /etc/init.d/
    sudo chmod a+x /etc/init.d/newwelcome
    sudo insserv /etc/init.d/newwelcome
    [ -f /home/pi/.bash_profile ] && mv /home/pi/.bash_profile /home/pi/.bash_profile.bak
    sudo cp /home/pi/piimage/misc/wheezy/bash_profile /home/pi/.bash_profile
    echo ". ~/.bash_profile" >> /home/pi/.bashrc

    sudo cp -f  /home/pi/piimage/misc/wheezy/pifstab /etc/fstab
    sudo mv /etc/rc.local /etc/rc.local.old
    sudo mv /home/pi/piimage/misc/wheezy/rc.local /etc/
    sudo chmod 755 /etc/rc.local

	echo "writing version number to package.json"
	PI_VERSION='ps2'
	VERSION=`cat /etc/debian_version`
	TODAY=`date +"%F"`
	ME='user'
	PACKAGE_JSON=/home/pi/piimage/package.json
	VERSION_NAME=${PI_VERSION}_${VERSION}_${ME}_${TODAY}

    if grep -q platform_version $PACKAGE_JSON;then
        echo "line present"
        sed -i 's/.*platform_version.*/    "platform_version":  "'$VERSION_NAME'",/' $PACKAGE_JSON
    else
        echo "line not present"
        sed -i '/.*version.*/a \    "platform_version":  "'$VERSION_NAME'", ' $PACKAGE_JSON
    fi
}

jessieSetup(){
	notify "Auto startup script"
	cp /home/pi/piimage/misc/jessie/start.sh /home/pi/
	sed -i '/sudo raspi-config --expand-rootfs/s/^/#/' /home/pi/start.sh
	cp /home/pi/piimage/misc/omx.py /home/pi

    notify "modify X"
    [ -f /home/pi/.config/openbox/lxde-rc.xml ] && mv /home/pi/.config/openbox/lxde-rc.xml /home/pi/.config/openbox/lxde-rc.xml.bak
    [ -d /home/pi/.config/openbox ] || mkdir -p /home/pi/.config/openbox
    ln -s /home/pi/piimage/misc/jessie/lxde-rc.xml /home/pi/.config/openbox/lxde-rc.xml
    mv /home/pi/.config/openbox/lxde-pi-rc.xml /home/pi/.config/openbox/lxde-pi-rc.xml.bak
    ln -s /home/pi/piimage/misc/jessie/lxde-rc.xml /home/pi/.config/openbox/lxde-pi-rc.xml
    [ -f /home/pi/.config/lxpanel/LXDE/panels/panel ] && mv /home/pi/.config/lxpanel/LXDE/panels/panel /home/pi/panel.bak
    sudo sed -e 's/^#xserver-command=X$/xserver-command=X -nocursor -s 0 dpms/g' -i /etc/lightdm/lightdm.conf

    notify "Autostart in LXDE settings"
    sudo mv /etc/xdg/lxsession/LXDE/autostart /etc/xdg/lxsession/LXDE/autostart.bak
    sudo cp /home/pi/piimage/misc/jessie/autostart /etc/xdg/lxsession/LXDE/
    sudo chmod +x  /etc/xdg/lxsession/LXDE/autostart

    notify "Autostart in LXDE-pi"
    sudo mv /etc/xdg/lxsession/LXDE-pi/autostart /etc/xdg/lxsession/LXDE-pi/autostart.bak
    sudo cp /home/pi/piimage/misc/jessie/autostart /etc/xdg/lxsession/LXDE-pi/
    sudo chmod +x  /etc/xdg/lxsession/LXDE-pi/autostart
    [ -f "/home/pi/.config/lxsession/LXDE-pi/autostart" ] && mv /home/pi/.config/lxsession/LXDE-pi/autostart /home/pi/.config/lxsession/LXDE-pi/autostart.bak

    notify "Autostart in ~/.config"
    if [ -f "/home/pi/.config/lxsession/LXDE-pi/autostart" ]
    then
        echo "Moving Default autostart File"
        sudo mv /home/pi/.config/lxsession/LXDE-pi/autostart /home/pi/.config/lxsession/LXDE-pi/autostart.bak
        sudo cp /home/pi/piimage/misc/jessie/autostart /home/pi/.config/lxsession/LXDE-pi/
        sudo chmod +x  /home/pi/.config/lxsession/LXDE-pi/autostart
    fi

    sudo sed -e 's/^BLANK_DPMS=.*/BLANK_DPMS=off/g' -i /etc/kbd/config
    sudo sed -i 's/.*CONF_SWAPSIZE=.*/CONF_SWAPSIZE=500/' /etc/dphys-swapfile

    notify "Quiet boot"
    sudo sed -i 's/splash/ /' /boot/cmdline.txt 
    sudo sed -i '$ a\ loglevel=1 quiet' /boot/cmdline.txt
    notify "Welcome Video"
    sudo cp /home/pi/piimage/misc/jessie/welcome.service /etc/systemd/system
    sudo systemctl daemon-reload
    sudo systemctl enable welcome.service

    [ -f /home/pi/.bash_profile ] && mv /home/pi/.bash_profile /home/pi/.bash_profile.bak
    sudo cp /home/pi/piimage/misc/jessie/bash_profile /home/pi/.bash_profile
    echo ". ~/.bash_profile" >> /home/pi/.bashrc

	echo "writing version number to package.json"
	PI_VERSION='ps3'
	VERSION=`cat /etc/debian_version`
	TODAY=`date +"%F"`
	ME='user'
	PACKAGE_JSON=/home/pi/piimage/package.json
	VERSION_NAME=${PI_VERSION}_${VERSION}_${ME}_${TODAY}

    if grep -q platform_version $PACKAGE_JSON;then
        echo "line present"
        sed -i 's/.*platform_version.*/    "platform_version":  "'$VERSION_NAME'",/' $PACKAGE_JSON
    else
        echo "line not present"
        sed -i '/.*version.*/a \    "platform_version":  "'$VERSION_NAME'", ' $PACKAGE_JSON
    fi
}

install_nodejs(){
    notify "nodejs 10.28 and npm "
    wget -cN http://nodejs.org/dist/v0.10.28/node-v0.10.28-linux-arm-pi.tar.gz
    tar -xvzf node-v0.10.28-linux-arm-pi.tar.gz
    sudo mkdir /opt/node
    sudo cp -R node-v0.10.28-linux-arm-pi/* /opt/node
    rm -r node-v0.10.28-linux-arm-pi
    sudo ln -s /opt/node/bin/node /usr/bin/node
    sudo ln -s /opt/node/lib/node /usr/lib/node
    sudo ln -s /opt/node/bin/npm /usr/bin/npm

    get_npm_modules
}

get_npm_modules(){
    cd /home/pi/piimage
    npm cache clean
    npm install
    echo "adding line in socket.io npm"
    sed "s/.*self\.transport\.onClose.*/if \(self\.transport\) self\.transport\.onClose\(\)/" -i /home/pi/piimage/node_modules/socket.io-client/lib/socket.js
}

accessPointSetup(){
    notify "Install Access Point Setup"
    sudo apt-get -y install hostapd dnsmasq
    
    if grep -q "denyinterfaces wlan0" /etc/dhcpcd.conf; then
        echo "Line present "
    else
        echo "#denyinterfaces wlan0 " | sudo tee -a /etc/dhcpcd.conf
    fi

    # sudo sed -i '/allow-hotplug wlan0/q' /etc/network/interfaces
    # echo "iface wlan0 inet static " | sudo tee -a  /etc/network/interfaces
    # echo "      address 172.24.1.1" | sudo tee -a /etc/network/interfaces
    # echo "      netmask 255.255.255.0" | sudo tee -a /etc/network/interfaces
    # echo "      network 172.24.1.0" | sudo tee -a /etc/network/interfaces
    # echo "      broadcast 172.24.1.255" | sudo tee -a /etc/network/interfaces

    if [ -f /etc/hostapd/hostapd.conf ];then
        sudo rm -rf /etc/hostapd/hostapd.conf
    fi
    
    sudo cp /home/pi/piimage/misc/hostapd.conf /etc/hostapd/
    sudo chmod 755 /etc/hostapd/hostapd.conf

    sudo sed -i 's|.*#DAEMON_CONF=""*.|DAEMON_CONF="/etc/hostapd/hostapd.conf"|' /etc/default/hostapd

    sudo mv /etc/dnsmasq.conf /etc/dnsmasq.conf.orig
    sudo cp /home/pi/piimage/misc/dnsmasq.conf /etc/dnsmasq.conf
    sudo chmod 755 /etc/dnsmasq.conf

    # sudo systemctl enable hostapd.service
    # sudo systemctl enable dnsmasq.service
}

install_livestreamer(){
    notify "livestreamer"
    sudo apt-get -y install python-pip
    sudo pip install livestreamer   #does not work with pip-3.2
}

install_browser(){
    notify "webkit 3.0"
    sudo apt-get -y install libwebkitgtk-3.0-dev

    notify "Chrome Install"
    sudo apt-get install -y rpi-chromium-mods
    sudo apt-get install -y python-sense-emu python3-sense-emu
    sudo apt-get install -y python-sense-emu-doc realvnc-vnc-viewer

    notify "install uzbl"
    cd /home/pi/
    git clone git://github.com/uzbl/uzbl.git
    cd uzbl
    git checkout tags/v0.9.0
    make
    sudo make install
    sudo ln -s /usr/local/bin/uzbl-browser /usr/local/bin/uzbl

    sudo apt-get -y install python3-pip
    sudo pip-3.2 install six
}

install_tools(){
    notify "screenshot app"
    cd /home/pi/piimage/tools/screenshot
    chmod +x make.sh
    ./make.sh

    notify "png view"
    cd /home/pi/piimage/tools/pngview
    chmod +x make.sh
    ./make.sh

    notify "openvg display"
    cd /home/pi/piimage/tools/openvg_display
    chmod +x make.sh
    ./make.sh
}

system_settings(){
    echo "Adding network-config symlink to /usr/bin"
    sudo rm -rf /usr/bin/network-config
    sudo ln -s /home/pi/piimage/misc/network-config /usr/bin/network-config
    sudo chmod +x  /home/pi/piimage/misc/network-config
    sudo chmod +x  /usr/bin/network-config

    notify "keep monitor ON"
    sudo sed -e 's/^BLANK_TIME=.*/BLANK_TIME=0/g' -i /etc/kbd/config
    sudo sed -e 's/^POWERDOWN_TIME=.*/POWERDOWN_TIME=0/g' -i /etc/kbd/config

    if grep -q framebuffer_depth /boot/config.txt; then
      sudo sed 's/^framebuffer_depth.*/framebuffer_depth=32/' -i /boot/config.txt
    else
      echo 'framebuffer_depth=32' | sudo tee -a /boot/config.txt > /dev/null
    fi

    if grep -q framebuffer_ignore_alpha /boot/config.txt; then
      sudo sed 's/^framebuffer_ignore_alpha.*/framebuffer_ignore_alpha=1/' -i /boot/config.txt
    else
          echo 'framebuffer_ignore_alpha=1' | sudo tee -a /boot/config.txt > /dev/null
    fi
    sudo sed 's/.*disable_overscan.*/disable_overscan=1/' -i /boot/config.txt
    sudo sed 's/.*hdmi_force_hotplug.*/hdmi_force_hotplug=1/' -i /boot/config.txt
    sudo sed 's/.*hdmi_group.*/hdmi_group=1/' -i /boot/config.txt
    sudo sed 's/.*hdmi_mode.*/hdmi_mode=4/' -i /boot/config.txt
    sudo sed 's/.*hdmi_drive.*/hdmi_drive=2/' -i /boot/config.txt
    sudo sed -i '$a\overscan_scale=1' /boot/config.txt
    sudo sed -i '/sdtv_mode/ a\sdtv_aspect=3' /boot/config.txt

    sudo sed -i -e 's/.*overscan_left.*/\#overscan_left=40/' -e 's/.*overscan_right.*/\#overscan_right=40/' -e 's/.*overscan_top.*/\#overscan_top=20/' -e 's/.*overscan_bottom.*/\#overscan_bottom=20/' -e 's/.*framebuffer_width.*/framebuffer_width=1280/' -e 's/.*framebuffer_height.*/framebuffer_height=720/'  /boot/config.txt

    sudo sed -i 's/.*XKBLAYOUT=.*/XKBLAYOUT="us"/' /etc/default/keyboard

    if grep -q display_rotate  /boot/config.txt; then
      echo "line already present"
    else
      echo 'display_rotate=0' | sudo tee -a /boot/config.txt > /dev/null
    fi

    echo 'gpu_mem_512=128' | sudo tee -a /boot/config.txt > /dev/null
    echo 'gpu_mem_1024=256' | sudo tee -a /boot/config.txt > /dev/null

    echo "configure piimage permissions"
    chmod +x -R /home/pi/piimage/misc/*
    chmod +x -R /home/pi/piimage/misc/upgrade_scripts/*

    notify "enable usb tethering"
    sudo cp /etc/network/interfaces  /etc/network/interfaces.bak
    sudo cp /home/pi/piimage/misc/interfaces /etc/network/interfaces

    notify "create directory for piimage"
    mkdir -p /home/pi/media
    chmod -R 777 /home/pi/media

    mkdir -p /home/pi/logs
    chmod -R 777 /home/pi/logs

    notify "gtk css"
    if [ -d "/home/pi/.config/gtk-3.0" ];then
        sudo rm -rf /home/pi/.config/gtk-3.0/gtk.css
        sudo cp /home/pi/piimage/misc/gtk.css /home/pi/.config/gtk-3.0/
        sudo chmod +x /home/pi/.config/gtk-3.0/gtk.css
    fi
}

fetch_videos(){
    notify "welcome video"
    cd /home/pi/
    wget https://s3.amazonaws.com/piimage/assets/brand_piimage_portrait.mp4
    wget https://s3.amazonaws.com/piimage/assets/brand_piimage_landscape.mp4
    wget https://s3.amazonaws.com/piimage/assets/update_portrait.mp4
    wget https://s3.amazonaws.com/piimage/assets/update_landscape.mp4 
}

start_node_install(){
    NODEEXIST=`which nodejs`
    if grep -q "jessie" /etc/*-release ;
    then
        notify "jessie"
        if [ ! "$NODEEXIST" ];then
            echo "nodejs not present"
            install_nodejs
        else
            echo "nodejs already present"
            sudo apt-get -y remove nodejs
            install_nodejs
        fi
        jessieSetup
    else
        notify "wheezy"
        install_nodejs
        wheezySetup
    fi
}

node_lib_changes(){
    sudo sed -i 's/.*http.get(API_VIDEO_INFO, params=params.*/\tres = http.get(API_VIDEO_INFO, params=params , headers=HLS_HEADERS)/' /usr/local/lib/python2.7/dist-packages/livestreamer/plugins/youtube.py
}

clean_update_notifiers(){
    if [ -f "/home/pi/.config/autostart/pi-conf-backup.desktop" ]
    then
        sudo rm /home/pi/.config/autostart/pi-conf-backup.desktop
    fi
}

remove_packages(){
    sudo apt-get -y remove --purge wolfram* zenity*
    sudo apt-get -y remove --purge scratch dillo galculator sonic-pi netsurf-gtk
    sudo apt-get -y remove --purge man-db leafpad gpicview xpdf qdbus manpages-dev

    sudo apt-get -y remove --purge greenfoot bluej  libreoffice*  oracle-java8-jdk pdf* # java related
    sudo apt-get -y remove claws-mail
    sudo apt-get -y remove  idle python3-pygame python-pygame python-tk idle3 python3-tk python3-rpi.gpio python-serial python3-serial
    sudo apt-get -y remove  python-picamera python3-picamera python3-pygame python-pygame python-tk python3-tk debian-reference-en
    sudo apt-get -y remove  dillo x2x scratch nuscratch timidity smartsim penguinspuzzle sonic-pi python3-numpy python3-pifacecommon
    sudo apt-get -y remove  python3-pifacedigitalio python3-pifacedigital-scratch-handler python-pifacecommon python-pifacedigitalio
    sudo apt-get -y remove   minecraft-pi python-minecraftpi

    sudo rm -rf BlueJ\ Projects Greenfoot\ Projects Scratch\ Projects
    sudo rm -rf /var/cache/apt/archives/*
    rm -rf /home/pi/python_games
    sudo apt-get -y autoremove
}

install_packages(){
    sudo apt-get install -y figlet
    notify "dependencies"
    sudo apt-get -y --fix-missing update
    sudo apt-get -y dist-upgrade
    sudo apt-get -y install git
    sudo apt-get -y install watchdog omxplayer x11-xserver-utils chkconfig unclutter liblockdev1-dev read-edid ifupdown
    sudo apt-get -y install fbi host ethtool nmap  cec-utils python3 rpi-update python-setuptools python3-setuptools libwebpdemux1

    notify "get update"
    sudo apt-get -y update --fix-missing
    sudo apt-get -y upgrade

}


export LC_ALL=C
export LANG=en_US.UTF-8

remove_packages
install_packages
install_livestreamer
install_browser
install_tools
system_settings
start_node_install
accessPointSetup
fetch_videos
node_lib_changes
clean_update_notifiers

sudo apt-get -y autoremove
sudo apt-get clean

sudo rpi-update

read -p "Installation complete ,  Reboot The System  [y/n] : "  REPLY
[ "$REPLY" != "y" ] || sudo reboot


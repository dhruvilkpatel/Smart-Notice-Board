#!/bin/bash

unclutter -idle 5 -root &
cd /home/pi/piimage

sudo bash /home/pi/piimage/misc/player-setup.sh

. /home/pi/.bash_profile
export WEBKIT_DISABLE_TBS=1
node pi-monitor.js
sleep 10 
sudo kill $(pidof python omx.py)
sudo pkill omxplayer
sleep infinity
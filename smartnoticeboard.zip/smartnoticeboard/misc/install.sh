#!/bin/bash


notify (){
    printf "\n"
    figlet -f digital -c $1
    printf "\n"
}

if [[ $EUID -eq 0 ]]; then
   echo "Root user installation not allowed. Use '. install.sh' "
   exit 1
fi

install_piimage(){
    # get figlet
    sudo apt-get install -y figlet

    # make sapce for piimage
    echo "remove previous ones"
    cd /home/pi/    
    sudo rm /home/pi/pi-image.zip
    sudo rm -rf piimage
    sudo rm -rf piImage

    # get piimage
    cd /home/pi/
    wget -cN http://xxxxxx.com/releases/pi-image.zip

    if [ $? -eq 0 ]; then
        unzip pi-image.zip
        mv piImage piimage
        notify "Install piimage"
        cd  /home/pi/piimage/misc/
        . install_piimage.sh 2>&1 | tee /home/pi/install.log
    else
        notify "FAIL to download piimage"
    fi
}

install_gui(){
    sudo apt-get install -y figlet
    notify "Install GUI"
    sudo apt-get -y update
    sudo apt-get -y upgrade
    sudo apt-get -y dist-upgrade
    sudo apt-get -y clean

    sudo apt-get install -y --no-install-recommends xserver-xorg
    sudo apt-get install -y raspberrypi-ui-mods
    notify "GUI install finished"
    echo "Goto sudo raspi-config and select 'Boot option' to desktop "
    exit 1;
}

echo "*******************************************************************************************************************************************"
echo "This method is not supported since Jessie, please use the piimage image at https://github.com/colloqi/piimage/blob/master/README.md#method-1-download-image-and-prepare-the-sd-card"
echo "*******************************************************************************************************************************************"
return 0

FUNCTION=$1
case "$FUNCTION" in 
	--install-gui)
		install_gui 2>&1 | tee -a /home/pi/install-gui.log
	;;
	*)
		install_piimage 
	;;
esac



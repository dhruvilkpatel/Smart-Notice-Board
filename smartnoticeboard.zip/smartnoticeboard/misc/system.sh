#!/bin/sh

FUNCTION=$1

CONFIG="/boot/config.txt"
HEIGHT=""
WIDTH=""
DNS_ENTRY_FILE="/etc/resolv.conf.head"

Portrait90(){
	echo "****  it's portrait 90 Degree  ****"
	sudo sed -i "s/.*display_rotate.*/display_rotate=1/" $CONFIG
    if [ $HEIGHT != "AUTO" ]
	then
		sudo sed -i   -e "s/.*framebuffer_width.*/framebuffer_width=$HEIGHT/" -e "s/.*framebuffer_height.*/framebuffer_height=$WIDTH/"  $CONFIG
	else
	    Large1080
	fi
    sudo sed -i "s/.*dtoverlay=vc4-fkms-v3d.*/\#dtoverlay=vc4-fkms-v3d/" $CONFIG
}

Portrait270(){
	echo "****  it's portrait 270 Degree ****"
	sudo sed -i "s/.*display_rotate.*/display_rotate=3/" $CONFIG
    if [ $HEIGHT != "AUTO" ]
	then
        sudo sed -i   -e "s/.*framebuffer_width.*/framebuffer_width=$HEIGHT/" -e "s/.*framebuffer_height.*/framebuffer_height=$WIDTH/"  $CONFIG
    else
	    Large1080
    fi
    sudo sed -i "s/.*dtoverlay=vc4-fkms-v3d.*/\#dtoverlay=vc4-fkms-v3d/" $CONFIG
}

LandScape(){
	echo "****  its landscape  ****"
	sudo sed -i 's/.*display_rotate.*/display_rotate=0/' $CONFIG
    if [ $HEIGHT != "AUTO" ]
	then
        sudo sed -i -e "s/.*framebuffer_width.*/framebuffer_width=$WIDTH/" -e "s/.*framebuffer_height.*/framebuffer_height=$HEIGHT/"  $CONFIG
    fi
    sudo sed -i "s/.*dtoverlay=vc4-fkms-v3d.*/dtoverlay=vc4-fkms-v3d/" $CONFIG
}

AutoEDID(){
	HEIGHT="AUTO"
	WIDTH="AUTO"
	echo "*** Based on EDID ***"
	sudo sed -i 's/.*hdmi_group.*/\#hdmi_group=1/' $CONFIG
	sudo sed -i 's/.*hdmi_mode.*/\#hdmi_mode=16/' $CONFIG
	sudo sed -i 's/.*framebuffer_height.*/\#framebuffer_height=1080/'  $CONFIG
	sudo sed -i 's/.*framebuffer_width.*/\#framebuffer_width=1920/' $CONFIG

	sudo sed -i 's/.*hdmi_force_hotplug=1.*/hdmi_force_hotplug=1/' $CONFIG
	sudo sed -i 's/.*hdmi_drive.*/\#hdmi_drive=2/' $CONFIG

    sudo sed -i -e 's/local/hdmi/' /home/pi/omx.py

}

Large1080(){
	HEIGHT="1080"
	WIDTH="1920"
	echo "*** 1080p screen ***"
    sudo sed -i 's/.*hdmi_group.*/hdmi_group=1/' $CONFIG
	sudo sed -i 's/.*hdmi_mode.*/hdmi_mode=16/' $CONFIG
	sudo sed -i 's/.*framebuffer_height.*/framebuffer_height=1080/'  $CONFIG
	sudo sed -i 's/.*framebuffer_width.*/framebuffer_width=1920/' $CONFIG

	sudo sed -i 's/.*hdmi_force_hotplug=1.*/hdmi_force_hotplug=1/' $CONFIG
	sudo sed -i 's/.*hdmi_drive.*/hdmi_drive=2/' $CONFIG

    sudo sed -i -e 's/local/hdmi/' /home/pi/omx.py
}

Small720(){
	HEIGHT="720"
	WIDTH="1280"
	echo "*** 720p screen ***"
    sudo sed -i 's/.*hdmi_group.*/hdmi_group=1/' $CONFIG
    sudo sed -i 's/.*hdmi_mode.*/hdmi_mode=4/' $CONFIG
	sudo sed -i 's/.*framebuffer_height.*/framebuffer_height=720/'  $CONFIG
	sudo sed -i 's/.*framebuffer_width.*/framebuffer_width=1280/' $CONFIG

	sudo sed -i 's/.*hdmi_force_hotplug=1.*/hdmi_force_hotplug=1/' $CONFIG
	sudo sed -i 's/.*hdmi_drive.*/hdmi_drive=2/' $CONFIG

    sudo sed -i -e 's/local/hdmi/' /home/pi/omx.py

}

PALsdtv(){
	HEIGHT="576"
	WIDTH="720"
	echo "**** PAL screen  ****"
	sudo sed -i 's/.*hdmi_force_hotplug=1.*/#hdmi_force_hotplug=1/' $CONFIG
	sudo sed -i 's/.*hdmi_drive.*/#hdmi_drive=2/' $CONFIG
	
	sudo sed -i 's/.*sdtv_mode.*/sdtv_mode=2/' $CONFIG

    sudo sed -i -e 's/hdmi/local/' /home/pi/omx.py
}

NTSCsdtv(){
	HEIGHT="480"
	WIDTH="720"
	echo "**** NTSC screen  ****"
	sudo sed -i 's/.*hdmi_force_hotplug=1.*/#hdmi_force_hotplug=1/' $CONFIG
	sudo sed -i 's/.*hdmi_drive.*/#hdmi_drive=2/' $CONFIG

	sudo sed -i 's/.*sdtv_mode.*/sdtv_mode=0/' $CONFIG

    sudo sed -i -e 's/hdmi/local/' /home/pi/omx.py

}

Change_Hostname(){
	DHCLIENT="/etc/dhcp/dhclient.conf"
	HOSTS="/etc/hosts"
	newname=$1

	echo " Change Host Name To :  $newname"

	sudo sed -i "s/.*127.0.1.1.*/127.0.1.1	$newname/" $HOSTS
	sudo sh -c "echo $newname > /etc/hostname"

    sudo hostname $newname

	#sudo sed -i "s/.*send host-name \".*/send host-name \"$newname\";/" $DHCLIENT
	#sudo sed -i "s/^send host-name =.*/#send host-name = gethostname();/" $DHCLIENT
}

downgrade(){
	pkill -f forever
	pkill -f node
	pkill -f uzbl
	pkill -f omx

	cd /home/pi/

	echo "rolling back to previous release"

	if [ -d "/home/pi/piimage.prev" ]
	then
		rm -rf  /home/pi/piimage.problem
		mv  /home/pi/piimage  /home/pi/piimage.problem
		cp -a  /home/pi/piimage.prev/  /home/pi/piimage
		sync
		sudo reboot
	fi
}

Change_Dns(){
	echo "*** Change DNS To : $1 $2"
	# sudo mv  /etc/resolv.conf  /etc/resolv.conf.bak
	# echo -e "nameserver $1 \nnameserver $2" >> /home/pi/resolv.conf
	# sudo mv /home/pi/resolv.conf /etc/resolv.conf
	if [ -z $1 ];then
        return 0
    fi

    NAME_SERVER_STR=''
    
    if [ ! -z "$1" ];then
        NAME_SERVER_STR="nameserver $1"
    fi

    if [ ! -z "$2" ];then
        NAME_SERVER_STR="${NAME_SERVER_STR}\nnameserver $2"
    fi
    
    echo -e "${NAME_SERVER_STR}" | sudo tee  "${DNS_ENTRY_FILE}"
    return 0
}

Factory_Reset(){
	HOSTNAME=$(id -un)

	echo "*** Reset Dispaly Settings ***"
	sudo sed 's/.*disable_overscan.*/disable_overscan=1/' -i /boot/config.txt
	sudo sed 's/.*overscan_scale.*/overscan_scale=0/' -i /boot/config.txt
	#sudo sed 's/.*hdmi_group.*/hdmi_group=1/' -i /boot/config.txt

	AutoEDID
	LandScape

	sudo sed 's/.*hdmi_force_hotplug.*/hdmi_force_hotplug=1/' -i /boot/config.txt
    #sudo sed -i -e 's/.*overscan_left.*/\#overscan_left=40/' -e 's/.*overscan_right.*/\#overscan_right=40/' -e 's/.*overscan_top.*/\#overscan_top=20/' -e 's/.*overscan_bottom.*/\#overscan_bottom=20/' -e 's/.*framebuffer_width.*/framebuffer_width=1280/' -e 's/.*framebuffer_height.*/framebuffer_height=720/'  /boot/config.txt

	sudo sed -i 's/.*XKBLAYOUT=.*/XKBLAYOUT="us"/' /etc/default/keyboard

	sudo sed -i 's/.*display_rotate.*/display_rotate=0/' /boot/config.txt

	echo "*** Reset Network Interface ***"
	sudo rm -rf /etc/network/interface
	sudo cp /home/pi/piimage/misc/interfaces /etc/network/interfaces

	echo "*** Reset config/setting ***"
	sudo rm -rf  /home/pi/piimage/config/_settings.json
	sudo rm -rf  /home/pi/piimage/config/_config.json
	echo 'pi:$apr1$G4yYdggH$aqJwlrg6yXYERl4DCZ2DT1' > /home/pi/piimage/htpasswd

	if [ $HOSTNAME == "raspberrypi" ]
	then
		echo "NO change to HOSTNAME"
	else
		HOSTNAME="raspberrypi"
		Change_Hostname $HOSTNAME
	fi
	echo "*** Changed name to  $HOSTNAME ***"

	Change_Dns "8.8.4.4" "8.8.8.8"
}

Install_Chrome(){
	echo "*** Installing Chrome ***"
	sudo pkill node 
	sudo pkill omx
	sudo pkill uzbl

	sudo apt-get -y update
	echo "y\n Y\n" | sudo apt-get -y dist-upgrade
	# echo "\n \n" | sudo apt-get install -y rpi-chromium-mods
	sudo apt-get install -y rpi-chromium-mods
	sudo apt-get install -y python-sense-emu python3-sense-emu
	sudo apt-get install -y python-sense-emu-doc realvnc-vnc-viewer
	sudo sed -e 's/^#xserver-command=X$/xserver-command=X -nocursor -s 0 dpms/g' -i /etc/lightdm/lightdm.conf
    # chromium-browser http://xxxxxx.com &
    sleep 10
    sudo reboot
}

One_Time(){
	# script to add execute permission
	chmod -R +x misc/upgrade_scripts
	node pi-upgrade.js
}

Change_Resolution(){
	case $1 in
		"720p") Small720
		;;
		"1080p") Large1080
		;;
		"PAL") PALsdtv
		;;
		"NTSC") NTSCsdtv
		;;
		*) AutoEDID
		;;
	esac
}

Change_Orientation(){
	case $1 in
		"portrait") Portrait90
		;;
		"portrait270") Portrait270
		;;
		"landscape") LandScape
		;;
		*) LandScape
		;;
	esac
}
Clean_Chrome_Session(){
	sed -i 's/\"exited_clean[^,]*/"exited_cleanly" : true/' /home/pi/.config/chromium/Default/Default/Preferences
	sed -i 's/\"exit_type[^,]*/"exit_type":"None"/' /home/pi/.config/chromium/Default/Default/Preferences
    sudo rm -rf /home/pi/.config/chromium/Default/SingletonLock
    sudo rm -rf /home/pi/.config/chromium/kiosk/SingletonLock
    sudo rm -rf /home/pi/.config/chromium/weblink/SingletonLock

	sudo rm -rf /home/pi/.cache/chromium/weblink/Default/Cache
	sudo rm -rf /home/pi/.cache/chromium/Default/Default/Cache
	sudo rm -rf /home/pi/.cache/chromium/kiosk/Default/Cache
}
Change_SSH_Password(){
	echo "Changing SSH password"
	
	NEW_PASSWORD=$1
	if [ -z $NEW_PASSWORD ];then
		echo "Password empty"
		exit 1
	fi

	USER_NAME=$(id -u -n)
	if [ -z $USER_NAME ];then
		echo "USER NAME empty"
		exit 1
	fi

	sudo passwd ${USER_NAME} <<-EOF
		${NEW_PASSWORD}
		${NEW_PASSWORD}
	EOF
}

Enable_Access_Point(){
	if grep -q "^denyinterfaces wlan0" /etc/dhcpcd.conf; then
  		echo "already in AP mode"
  		return 0
	fi

	if [ ! -f "/etc/hostapd/hostapd.conf" ];then
		echo " ============== copy setting hostapd.conf file ===================="
		sudo cp /home/pi/piimage/misc/hostapd.conf /etc/hostapd/
	    sudo chmod 755 /etc/hostapd/hostapd.conf
		CPUID=$(cat /proc/cpuinfo  |grep "Serial" | cut -f 2 -d : | tr -d " ")
		ACCESS_POINT_NAME=$(echo "${CPUID: -4}")
		sudo sed -i 's/^ssid=.*/ssid=piplayer_'$ACCESS_POINT_NAME'/' /etc/hostapd/hostapd.conf
		sudo sed -i 's|.*#DAEMON_CONF=""*.|DAEMON_CONF="/etc/hostapd/hostapd.conf"|' /etc/default/hostapd
	fi

	#if [ ! -f  "/etc/dnsmasq.conf" ];then
    sudo cp /home/pi/piimage/misc/dnsmasq.conf /etc/dnsmasq.conf
    sudo chmod 755 /etc/dnsmasq.conf
	#fi

	sudo sed -i 's/.*denyinterfaces wlan0*./denyinterfaces wlan0/' /etc/dhcpcd.conf

	if grep -q "^iface eth0 inet" /etc/network/interfaces; then
        echo "Adding wlan static IP info /etc/network/interfaces"
        sudo sed -i '/allow-hotplug wlan0/q' /etc/network/interfaces
        echo "iface wlan0 inet static " | sudo tee -a  /etc/network/interfaces
        echo "      address 192.168.100.1" | sudo tee -a /etc/network/interfaces
        echo "      netmask 255.255.255.0" | sudo tee -a /etc/network/interfaces
        echo "      network 192.168.100.0" | sudo tee -a /etc/network/interfaces
        echo "      broadcast 192.168.100.255" | sudo tee -a /etc/network/interfaces
    else
        echo "Adding wlan static IP info /etc/dhcpcd.conf"
        sed -i '/^interface wlan0/d' /etc/dhcpcd.conf
        sed -i  '/static ip_address=192.168.100.1/d' /etc/dhcpcd.conf
        sudo sed -i '/denyinterfaces wlan0/iinterface wlan0\n\tstatic ip_address=192.168.100.1/24\n' /etc/dhcpcd.conf
    fi

    #delete the network info if present
    sudo sed -i '/network={/,+4d' /etc/wpa_supplicant/wpa_supplicant.conf


	# Start And enable service 
    sudo systemctl enable dnsmasq.service
    sudo systemctl start dnsmasq.service

	sudo systemctl unmask hostapd.service
	sudo systemctl enable hostapd.service
	sudo systemctl daemon-reload

    sudo systemctl start hostapd.service
	echo "Wi-fi in Access Point Mode"
}

Disable_Access_Point(){
	# Don't change if current mode is same 
	if grep -q "^\#denyinterfaces wlan0" /etc/dhcpcd.conf; then
  		echo "already in  Wifi mode"
  		return 0
	fi
	# Stop And Disable service
    sudo ifdown wlan0
	sudo systemctl stop hostapd.service
    sudo systemctl stop dnsmasq.service

	sudo systemctl disable hostapd.service
    sudo systemctl disable dnsmasq.service
	sudo systemctl daemon-reload
	
    # allow wlan0 interface 
	sudo sed -i 's/.*denyinterfaces wlan0*./#denyinterfaces wlan0/' /etc/dhcpcd.conf
	
	if grep -q "^iface eth0 inet" /etc/network/interfaces; then
	    #Change text in /etc/network/interfaces
        sudo sed -i '/allow-hotplug wlan0/q' /etc/network/interfaces
        echo "iface wlan0 inet manual" | sudo tee -a  /etc/network/interfaces
        echo "wpa-roam /etc/wpa_supplicant/wpa_supplicant.conf" | sudo tee -a /etc/network/interfaces
        echo "wireless-power off" | sudo tee -a /etc/network/interfaces
        echo "iface default inet dhcp" | sudo tee -a /etc/network/interfaces
	else
        echo "Deleting wlan static IP info /etc/dhcpcd.conf"
        sudo sed -i '/^interface wlan0/d' /etc/dhcpcd.conf
        sudo sed -i  '/static ip_address=192.168.100.1/d' /etc/dhcpcd.conf
    fi
	echo "Access Point mode disabled"
}


show_help(){
cat <<-EOF 
    USAGE:  /bin/bash system.sh [OPTIONS=VALUE]

            Currently Multiple options are not allowed. You can use only single option
            Ex: /bin/bash system --resolution=720p portrait

    OPTIONS:

        --resolution
                       	Used to change display resolution and orientation
                       	Allowed values can be 720p , 1080p , PAL , NTSC
                    	Allowed values can be portrait , portrait270 , landscape					   
                       	ex: /bin/bash system --resolution 720p landscape

        --change-hostname
                        Used to change hostname of your raspberry pi
                        ex: /bin/bash system --change-hostname=mycomputer
        --factory-reset 
                        Used to perform factory reset of raspberry pi 
                        All the configuration will be set to default values, That is screen at 720p, 
                        orientation at  Landscape
                        hostname changed to raspberrypi
                        ethernet set to DHCP mode
                        ex: /bin/bash system --factory-reset
        --enable-access-point
                        Make raspberry pi as access point device
        --disable-access-point
       	                Disable access point feature in Raspberry Pi
        --install-chrome
                        This option will install chromium browser for old release.
                        All images with version greater than 1.8.0 includes chromium browser by default, 
                        In case you need chromium browser for old images(versions < 1.8.0) use this option.
                        ex: /bin/bash system --install-chrome
        --change-dns
                        This option will change the dns entry.
                        ex: /bin/bash system --change-dns 8.8.4.4 8.8.8.8

EOF

}

case "$FUNCTION" in 
	--resolution)
		# R_VALUE=`echo $1 | sed 's/[-a-zA-Z0-9]*=//'`
		Change_Resolution $2
		Change_Orientation $3
	;;
	--change-hostname=*)
		NAME=`echo $1 | sed 's/[-a-zA-Z0-9]*=//; s/ /-/g; s/^-//; s/[^-a-zA-Z0-9]//g'`
		Change_Hostname $NAME
	;;
	--factory-reset)
		Factory_Reset
	;;
	--install-chrome) 
		Install_Chrome
	;;
	--change-dns) 
		Change_Dns $2 $3
	;;
	--one-time) 
		One_Time
	;;
	--enable-access-point)
		Enable_Access_Point
	;;
	--disable-access-point)
		Disable_Access_Point
    ;;
	--change-ssh-password)
		Change_SSH_Password $2
	;;
	--clean-chrome-session)
		Clean_Chrome_Session
	;;
	*)
		echo "**** Check Your Command Line Options *** "
		echo ""
		echo ""
		show_help
		exit 1
	;;
esac
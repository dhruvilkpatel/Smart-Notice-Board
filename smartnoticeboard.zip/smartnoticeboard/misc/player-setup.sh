#!/bin/sh

CONFIG=/etc/network/interfaces
WIFI_SUPPLICANT="/etc/wpa_supplicant/wpa_supplicant.conf"
FILE_LOCATION="/boot/player-config.txt"


Change_Wifi(){
    sed -i '/update_config=1/q0' $WIFI_SUPPLICANT

    echo "network={" >> $WIFI_SUPPLICANT
    echo "  ssid=\"$WIFI_NAME\" " >> $WIFI_SUPPLICANT
    if [ -z "$WIFI_PASSWORD" ]; then
        echo "  key_mgmt=NONE " >>  $WIFI_SUPPLICANT
    else
        echo "  psk=\"$WIFI_PASSWORD\" " >>  $WIFI_SUPPLICANT
    fi

    if [ "$IS_WIFI_HIDDEN" -eq 1 ]; then
        echo "  scan_ssid=1 " >> $WIFI_SUPPLICANT
    fi
        
    echo "}" >>  $WIFI_SUPPLICANT

    if grep -q "^iface eth0 inet" $CONFIG
    then
        sudo ifdown --force wlan0
        sudo ifup wlan0
    else
        sudo ifconfig wlan0 down
        sudo ifconfig wlan0 up
    fi

}

Change_Server(){
    sed  -i 's/.*config_serv.*/    "config_server": "'$SERVER_NAME'",/' /home/pi/piimage/package.json
    sed -i 's/.*media_serv.*/    "media_server": "'$SERVER_NAME'",/' /home/pi/piimage/package.json
}

Make_Player_Modification(){
    echo " make modification"
    SERVER_NAME=$(cat $FILE_LOCATION | grep server_name | cut -d '=' -f2 | tr -d '"')
    WIFI_NAME=$(cat $FILE_LOCATION | grep wifi_name | cut -d '=' -f2 | tr -d '"')
    WIFI_PASSWORD=$(cat $FILE_LOCATION | grep wifi_password | cut -d '=' -f2 | tr -d '"')
    IS_WIFI_OPEN=$(cat $FILE_LOCATION | grep wifi_open | cut -d '=' -f2 | tr -d '"')
    IS_WIFI_HIDDEN=$(cat $FILE_LOCATION | grep wifi_hidden | cut -d '=' -f2 | tr -d '"')
    
    if [ ! -z "$SERVER_NAME" ];then
        Change_Server
    fi

    if [ ! -z "$WIFI_NAME" ];then
        sudo /bin/bash /home/pi/piimage/misc/system.sh --disable-access-point
        Change_Wifi
    else
        sudo /bin/bash /home/pi/piimage/misc/system.sh --enable-access-point
    fi
}

CPUID=$(cat /proc/cpuinfo  |grep "Serial" | cut -f 2 -d : | tr -d " ")
ACCESS_POINT_NAME=$(echo "${CPUID: -4}")
sudo sed -i 's/^ssid=.*/ssid=piplayer_'$ACCESS_POINT_NAME'/' /etc/hostapd/hostapd.conf

if [ -f "$FILE_LOCATION" ];then
    Make_Player_Modification
else
    sudo /bin/bash /home/pi/piimage/misc/system.sh --enable-access-point
fi

sed -i  's/.*player-setup.*//g' /home/pi/start.sh
sudo raspi-config --expand-rootfs
sudo rm -rf /home/pi/piimage/misc/player-setup.sh
sudo rm -rf "$FILE_LOCATION"
sudo reboot
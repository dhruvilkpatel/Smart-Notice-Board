#ifndef OPENVG_DISPLAY_H
#define OPENVG_DISPLAY_H

#define PAUSE_OPENVG 80
#define PLAY_OPENVG 81

#define CMD_START 0
#define CMD_END 1

#define CLK_CMD_NO_CLOCK 0
#define CLK_CMD_CLOCK_TOP 1
#define CLK_CMD_CLOCK_BOTTOM 2

#define TICKER_CMD_DISABLE 0
#define TICKER_CMD_ENABLE 1

#define H_LEFT 0
#define H_MIDDLE 1
#define H_RIGHT 2
#define V_TOP 0
#define V_MIDDLE 1
#define V_BOTTOM 2

#define CLK_FMT_HOUR24 0
#define CLK_FMT_HOUR12 1

#define MAX_CMDS_AND_PARAMS 13
#define MIN_CMDS 3
#define EMERGENCY_MSG_NUM_PARAMS 3
#define TICKER_NUM_PARAMS 7

#define ERROR_EMERGENCY_MSG_CMD -2
#define ERROR_CLOCK_CMD -3
#define ERROR_TICKER_CMD -4
#define ERROR_NOT_ENOUGH_TOKENS -5
#define ERROR_BAD_ARGUMENT -6
#define ERROR_MSG_TRUNC -7

#define RAW_BUF_LEN 8192
#define MSG_BUF_LEN 6144
#define TICKER_BUF_LEN 22528

typedef struct {
  int emergency_msg_cmd;
  int clock_cmd;
  int ticker_cmd;
  int clock_format;
  int emergency_msg_h_pos;
  int emergency_msg_v_pos;
  int ticker_x;
  int ticker_y;
  int ticker_width;
  int ticker_speed;
  int ticker_direction;
  int ticker_font_size;
  char emergency_msg[MSG_BUF_LEN];
  char ticker_msg[TICKER_BUF_LEN];
} T_CMD_INFO;

#endif //OPENVG_DISPLAY_H
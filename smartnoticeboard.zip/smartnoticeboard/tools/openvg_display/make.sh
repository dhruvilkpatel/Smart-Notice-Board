cd /home/pi/piimage/tools/openvg_display
make
sudo rm -f /usr/local/bin/openvg_display
sudo cp /home/pi/piimage/tools/openvg_display/openvg_display /usr/local/bin/openvg_display
sudo chmod +x /usr/local/bin/openvg_display

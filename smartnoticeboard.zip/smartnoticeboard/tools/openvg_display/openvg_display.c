#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <signal.h>
#include <fcntl.h>
#include <limits.h>
#include "VG/openvg.h"
#include "VG/vgu.h"
#include "fontinfo.h"
#include "shapes.h"
#include "openvg_display.h"


#define TICKER_BG_R 0
#define TICKER_BG_G 0
#define TICKER_BG_B 0
#define TICKER_BG_A 0.7

#define FONT_SIZE 35
#define PADDING_CLOCK 5
#define PADDING 20
#define OFFSET 0

#define ROUND_X 10
#define ROUND_Y 10

#define BG_R 51
#define BG_G 51
#define BG_B 51
#define BG_A 0.9

#define TEXT_R 255
#define TEXT_G 255
#define TEXT_B 255
#define TEXT_A 1

#define TEXTDEPTH(fontsize)  (TextDepth(SansTypeface, fontsize))
#define TEXTHEIGHT(fontsize)  (TextHeight(SansTypeface, fontsize))
#define TEXTLENGTH(str,fontsize)  (TextWidth((str), SansTypeface, fontsize))



void getClock(int fmt, int* hours, int* min, char* suffix);
void showEmergencyMessage(int width, int height, int hPos, int vPos,char *msg);
void showClock(int width, int height, int clockCmd, int clockFmt);
void showRollingText(int x, int y, int width, int fontsize,int textX, char *msg);
int parse_input(char* args_str, T_CMD_INFO* cmd_info);
int u8_byte_len(const char *utf8_buf, const int utf8_len);

void handle_sigint(int sig)
{
   
    finish();
    exit(0);
}


int main(int argc, char** argv) {
    int pauseOpenVg;
    int hPos, vPos,msgCmd;
    int clockCmd, clockFmt;
    int tickerCmd,tickerX,tickerY,tickerWidth,tickerSpeed,tickerDir,tickerFontSize;
    char* tickerText;
    int tickerTextX,tickerTextXInitial, tickerLengthPixels, step;
    char steps[] = {2,4,8};
    char* msg;
	int width, height;

    char args_str[RAW_BUF_LEN];
    ssize_t len;
    unsigned long loop_count;
    
    T_CMD_INFO cmd_info;

    fprintf(stdout, "Started the openvg_display process\n");
	signal(SIGTERM, handle_sigint);

    init(&width, &height);			

    pauseOpenVg = PLAY_OPENVG;
    msgCmd = CMD_END;
    tickerCmd = TICKER_CMD_DISABLE;

    clockCmd = CLK_CMD_NO_CLOCK;
    clockFmt = CLK_FMT_HOUR24;

    int flags = fcntl(STDIN_FILENO, F_GETFL, 0);

    int result = fcntl(STDIN_FILENO, F_SETFL, flags | O_NONBLOCK);
    if (result == -1) {
        fprintf(stderr, "Failed to set stdin to non-blocking\n");
    }

    memset(args_str, 0, sizeof(args_str));
   
    loop_count = 0;

    while (1) {
        memset(args_str, 0, sizeof(args_str));
        len = read(STDIN_FILENO, args_str, RAW_BUF_LEN);

       
        if (len > 0) {
           
            int result = parse_input(args_str, &cmd_info);
            if (result < 0) {
                fprintf(stderr, "Failed to parse input: %d\n", result);
                fprintf(stderr, "Input was: %s\n", args_str);
            } else if (result == 0){
                msgCmd = cmd_info.emergency_msg_cmd;
                if (msgCmd == CMD_START) {
                    hPos = cmd_info.emergency_msg_h_pos;
                    vPos = cmd_info.emergency_msg_v_pos;
                    msg = cmd_info.emergency_msg;
                }

                clockCmd = cmd_info.clock_cmd;
                if (clockCmd != CLK_CMD_CLOCK_BOTTOM && clockCmd != CLK_CMD_CLOCK_TOP) {
                    clockCmd = CLK_CMD_NO_CLOCK;
                }
                if (clockCmd != CLK_CMD_NO_CLOCK) {
                    clockFmt = cmd_info.clock_format;
                }

                tickerCmd = cmd_info.ticker_cmd;
                if (tickerCmd == TICKER_CMD_ENABLE) {
                    tickerWidth = cmd_info.ticker_width;
                    tickerSpeed = cmd_info.ticker_speed;
                    tickerX = cmd_info.ticker_x;
                    tickerY = cmd_info.ticker_y;
                    tickerFontSize = cmd_info.ticker_font_size;
                    tickerDir = cmd_info.ticker_direction;
                    tickerText = cmd_info.ticker_msg;

                    tickerLengthPixels = TEXTLENGTH(tickerText, tickerFontSize);
                    step = steps[tickerSpeed - 1];
                    if (tickerWidth == 0)
                        tickerWidth = width;
                    if (tickerDir == 0) {
                        tickerTextXInitial = tickerX + tickerWidth - PADDING - OFFSET;
                    } else {
                        tickerTextXInitial = tickerX - tickerLengthPixels;
                    }
                    tickerTextX = tickerTextXInitial;
                }
                if (msgCmd == CMD_START || clockCmd != CLK_CMD_NO_CLOCK || tickerCmd == TICKER_CMD_ENABLE) {
                    if (pauseOpenVg == PAUSE_OPENVG) {
                        init(&width, &height);			
                    pauseOpenVg = PLAY_OPENVG;
                } else {
                    if (pauseOpenVg == PLAY_OPENVG)
                        finish();
                    pauseOpenVg = PAUSE_OPENVG;
                }

            } else if (result == PLAY_OPENVG){
                if (pauseOpenVg == PAUSE_OPENVG)
                    init(&width, &height);			
                pauseOpenVg = PLAY_OPENVG;
            } else if (result == PAUSE_OPENVG){
                if (pauseOpenVg == PLAY_OPENVG)
                    finish();
                pauseOpenVg = PAUSE_OPENVG;
            }
        }

        if (pauseOpenVg == PLAY_OPENVG) {
            Start(width, height);
            BackgroundRGB(0, 0, 0, 0);	

            if (tickerCmd == TICKER_CMD_ENABLE) {
                if (tickerDir == 0) {
                    if (tickerTextX < -1 * tickerLengthPixels)
                        tickerTextX = tickerTextXInitial;
                    else
                        tickerTextX -= step;
                } else {
                    if (tickerTextX > (tickerWidth - PADDING - OFFSET))
                        tickerTextX = tickerTextXInitial;
                    else
                        tickerTextX += step;
                }
                showRollingText(tickerX, tickerY, tickerWidth, tickerFontSize,tickerTextX, tickerText);
            }
            if (msgCmd == CMD_START) {
                showEmergencyMessage(width,height,hPos,vPos,msg);
            }
            if (clockCmd != CLK_CMD_NO_CLOCK) {
                showClock(width,height,clockCmd,clockFmt);
            }


            End();						
            if (tickerCmd == TICKER_CMD_ENABLE) {
                usleep(5);
            } else {
                sleep(1);
            }

            loop_count++;
            if (loop_count == 5000000) {
                
                loop_count = 0;
                finish();
                init(&width, &height);
            }
        } else {
            usleep(10000);
        }
    }

    finish();
    exit(0);
}


void getClock(int fmt, int* hours, int* min, char* suffix) {
    struct tm* t;
    time_t epoch;

    epoch = time(NULL);
    t = localtime(&epoch);

    *hours = (fmt == CLK_FMT_HOUR12)? t->tm_hour%12: t->tm_hour;
    if (fmt == CLK_FMT_HOUR12 && *hours == 0) {
        *hours = 12;
    }
    *min = t->tm_min;
}

void showClock(int width, int height, int clockCmd, int clockFmt) {

    int textLength;
    int textHeight = TEXTHEIGHT(FONT_SIZE);
    int textDepth = TEXTDEPTH(FONT_SIZE);

    int xRect,yRect,wRect,hRect;
    int xText,yText;

    int hours, min;
    char timeStr[16];
    char timeSuffix[3];

    getClock(clockFmt, &hours, &min, timeSuffix);
    sprintf(timeStr, "%02d:%02d", hours, min);

    textLength = TEXTLENGTH(timeStr,FONT_SIZE) + PADDING_CLOCK + OFFSET;

    hRect = textHeight + textDepth + 2 * PADDING_CLOCK;
    wRect = textLength + 2*PADDING_CLOCK;

    xText = width - OFFSET - PADDING_CLOCK;
    xRect = width - textLength - 2*PADDING_CLOCK - OFFSET;

    if (clockCmd == CLK_CMD_CLOCK_TOP) {
        yText = height - textHeight - OFFSET - PADDING_CLOCK;
        yRect = height - textHeight - textDepth - 2 * PADDING_CLOCK - OFFSET;

        Fill(BG_R, BG_G, BG_B, BG_A); 
        Roundrect(xRect, yRect, wRect, hRect,ROUND_X,ROUND_Y);

        Fill(TEXT_R,TEXT_G,TEXT_B,TEXT_A);
        TextEnd(xText, yText, timeStr, SansTypeface,FONT_SIZE);
    } else {
        yText = textDepth + OFFSET + PADDING_CLOCK;
        yRect = OFFSET;

        Fill(BG_R, BG_G, BG_B, BG_A);  
        Roundrect(xRect, yRect, wRect, hRect,ROUND_X,ROUND_Y);

        Fill(TEXT_R,TEXT_G,TEXT_B,TEXT_A);
        TextEnd(xText, yText, timeStr, SansTypeface,FONT_SIZE);
    }
}

void showEmergencyMessage(int width, int height, int hPos, int vPos,char *msg) {

    int textLength = TEXTLENGTH(msg,FONT_SIZE) + PADDING + OFFSET;
    int textHeight = TEXTHEIGHT(FONT_SIZE);
    int textDepth = TEXTDEPTH(FONT_SIZE);

    int xRect,yRect,wRect,hRect;
    int xText,yText;

    hRect = textHeight + textDepth + 2 * PADDING;
    wRect = textLength + 2*PADDING;

    if (vPos == V_TOP) {
        yText = height - textHeight - OFFSET - PADDING;
        yRect = height - textHeight - textDepth - 2 * PADDING - OFFSET;
    } else if (vPos == V_BOTTOM) {
        yText = textDepth + OFFSET + PADDING;
        yRect = OFFSET;
    } else {
        yText = (height/2) - textHeight;
        yRect = (height/2) - textHeight - textDepth - PADDING;
    }

    if (hPos == H_RIGHT) {
        xText = width - PADDING - OFFSET;
        xRect = width - textLength - 2*PADDING - OFFSET;

        Fill(BG_R, BG_G, BG_B, BG_A); 
        Roundrect(xRect, yRect, wRect, hRect,ROUND_X,ROUND_Y);

        Fill(TEXT_R,TEXT_G,TEXT_B,TEXT_A);
        TextEnd(xText, yText, msg, SansTypeface, FONT_SIZE);

    } else if (hPos == H_LEFT) {

        xText = PADDING + OFFSET;
        xRect = OFFSET;

        Fill(BG_R, BG_G, BG_B, BG_A);  
        Roundrect(xRect, yRect, wRect, hRect,ROUND_X,ROUND_Y);

        Fill(TEXT_R,TEXT_G,TEXT_B,TEXT_A);
        Text(xText, yText, msg, SansTypeface, FONT_SIZE);

    } else {
        xText = width/2;
        xRect = (width - textLength)/2 - PADDING;

        Fill(BG_R, BG_G, BG_B, BG_A);  
        Roundrect(xRect, yRect, wRect, hRect,ROUND_X,ROUND_Y);

        Fill(TEXT_R,TEXT_G,TEXT_B,TEXT_A);
        TextMid(xText, yText, msg, SansTypeface, FONT_SIZE);

    }
}

void showRollingText(int x, int y, int width, int fontsize,int textX, char *msg) {

    int textHeight = TEXTHEIGHT(fontsize);
    int textDepth = TEXTDEPTH(fontsize);

    int xRect,yRect,wRect,hRect;
    int xText,yText;

    hRect = textHeight + textDepth + 2 * PADDING;
    wRect = width;

    yText = y + textDepth + OFFSET + PADDING;
    yRect = y + OFFSET;

    xText = textX + PADDING + OFFSET;
    xRect = x + OFFSET;

    Fill(TICKER_BG_R, TICKER_BG_G, TICKER_BG_B, TICKER_BG_A);
    Rect(xRect, yRect, wRect, hRect);

    ClipRect(xRect, yRect, wRect, hRect);
    Fill(TEXT_R,TEXT_G,TEXT_B,TEXT_A);
    Text(xText, yText, msg, SansTypeface, fontsize);
    ClipEnd();

}

int parse_input(char* args_str, T_CMD_INFO* cmd_info) {
    char* args[MAX_CMDS_AND_PARAMS];
    char* p;
    long cmd_value;
    int emergency_msg_len = 0;
    int ticker_len = 0;
    int i = 0;
    int tokens_to_be_parsed = 0;
    int num_args = 0;
    int byte_len;

    bzero(args, sizeof(args));

    p = strtok(args_str, " ");
    if (!p) {
        return ERROR_NOT_ENOUGH_TOKENS;
    }
    cmd_value = strtol(p, NULL, 10);

    if (cmd_value == PAUSE_OPENVG) {
        return PAUSE_OPENVG;
    } else if (cmd_value == PLAY_OPENVG) {
        return PLAY_OPENVG;
    }

    if (cmd_value != CMD_START && cmd_value != CMD_END) {
        return ERROR_EMERGENCY_MSG_CMD;
    }
    cmd_info->emergency_msg_cmd = (int)cmd_value;  

    p = strtok(NULL, " ");
    if (!p) {
        return ERROR_NOT_ENOUGH_TOKENS;
    }
    cmd_value = strtol(p, NULL, 10);
    if (cmd_value != CLK_CMD_CLOCK_TOP && cmd_value != CLK_CMD_CLOCK_BOTTOM && cmd_value != CLK_CMD_NO_CLOCK) {
        return ERROR_CLOCK_CMD;
    }
    cmd_info->clock_cmd = (int)cmd_value;  

    p = strtok(NULL, " ");
    if (!p) {
        return ERROR_NOT_ENOUGH_TOKENS;
    }
    cmd_value = strtol(p, NULL, 10);
    if (cmd_value != TICKER_CMD_ENABLE && cmd_value != TICKER_CMD_DISABLE) {
        return ERROR_TICKER_CMD;
    }
    cmd_info->ticker_cmd = (int)cmd_value;  

    tokens_to_be_parsed += (cmd_info->clock_cmd != CLK_CMD_NO_CLOCK) ? 1 : 0; 
    tokens_to_be_parsed += (cmd_info->emergency_msg_cmd == CMD_START) ?  EMERGENCY_MSG_NUM_PARAMS : 0;
    tokens_to_be_parsed += (cmd_info->ticker_cmd == TICKER_CMD_ENABLE) ? TICKER_NUM_PARAMS : 0;

   
    while(p && tokens_to_be_parsed) {
        p = strtok(NULL, " ");
        args[num_args++] = p;
        tokens_to_be_parsed--;
    }

    if (tokens_to_be_parsed) {
        return ERROR_NOT_ENOUGH_TOKENS;
    }

   
    if (cmd_info->emergency_msg_cmd == CMD_START) {
        cmd_value = strtol(args[i++], NULL, 10);
        if (cmd_value == LONG_MAX || cmd_value == LONG_MIN) {
            return ERROR_BAD_ARGUMENT;
        }
        emergency_msg_len = (int)cmd_value;  
        cmd_value = strtol(args[i++], NULL, 10);
        if (cmd_value == LONG_MAX || cmd_value == LONG_MIN) {
            return ERROR_BAD_ARGUMENT;
        }
        cmd_info->emergency_msg_h_pos = (int)cmd_value; 

        cmd_value = strtol(args[i++], NULL, 10);
        if (cmd_value == LONG_MAX || cmd_value == LONG_MIN) {
            return ERROR_BAD_ARGUMENT;
        }
        cmd_info->emergency_msg_v_pos = (int)cmd_value; 
    if (cmd_info->clock_cmd != CLK_CMD_NO_CLOCK) {
        cmd_value = strtol(args[i++], NULL, 10);
        if (cmd_value == LONG_MAX || cmd_value == LONG_MIN) {
            return ERROR_BAD_ARGUMENT;
        }
        cmd_info->clock_format = (int)cmd_value; 
    }

    if (cmd_info->ticker_cmd) {
        cmd_value = strtol(args[i++], NULL, 10);
        if (cmd_value == LONG_MAX || cmd_value == LONG_MIN) {
            return ERROR_BAD_ARGUMENT;
        }
        ticker_len = (int)cmd_value;  

        cmd_value = strtol(args[i++], NULL, 10);
        if (cmd_value == LONG_MAX || cmd_value == LONG_MIN) {
            return ERROR_BAD_ARGUMENT;
        }
        cmd_info->ticker_x = (int)cmd_value;  

        cmd_value = strtol(args[i++], NULL, 10);
        if (cmd_value == LONG_MAX || cmd_value == LONG_MIN) {
            return ERROR_BAD_ARGUMENT;
        }
        cmd_info->ticker_y = (int)cmd_value;  

        cmd_value = strtol(args[i++], NULL, 10);
        if (cmd_value == LONG_MAX || cmd_value == LONG_MIN) {
            return ERROR_BAD_ARGUMENT;
        }
        cmd_info->ticker_width = (int)cmd_value;  

        cmd_value = strtol(args[i++], NULL, 10);
        if (cmd_value == LONG_MAX || cmd_value == LONG_MIN) {
            return ERROR_BAD_ARGUMENT;
        }
        cmd_info->ticker_speed = (int)cmd_value; 

        cmd_value = strtol(args[i++], NULL, 10);
        if (cmd_value == LONG_MAX || cmd_value == LONG_MIN) {
            return ERROR_BAD_ARGUMENT;
        }
        cmd_info->ticker_direction = (int)cmd_value;  

        cmd_value = strtol(args[i++], NULL, 10);
        if (cmd_value == LONG_MAX || cmd_value == LONG_MIN) {
            return ERROR_BAD_ARGUMENT;
        }
        cmd_info->ticker_font_size = (int)cmd_value;  
    }

    if (i != num_args) {
        printf("Internal error: %d %d", i, num_args);
    }

    
    if (cmd_info->emergency_msg_cmd == CMD_START || cmd_info->ticker_cmd == TICKER_CMD_ENABLE) {
        p = strtok(NULL, "");
        if (!p) {
            return ERROR_NOT_ENOUGH_TOKENS;
        }
    }

    int data_len = strlen(p);
    if (data_len < emergency_msg_len + ticker_len) {
        fprintf(stderr, "Remaining data: %d, emergency message len: %d, ticker len: %d\n",
                data_len, emergency_msg_len, ticker_len);
        return ERROR_MSG_TRUNC;
    }
    memset(cmd_info->emergency_msg, 0, sizeof(cmd_info->emergency_msg));
    if (emergency_msg_len > 0) {
        byte_len = u8_byte_len(p, emergency_msg_len);
        memcpy(cmd_info->emergency_msg, p, byte_len);
       
        p+= byte_len + 1; 
    }
    if (ticker_len > 0) {
        byte_len = u8_byte_len(p, ticker_len);
        memset(cmd_info->ticker_msg, 0, sizeof(cmd_info->ticker_msg));
        memcpy(cmd_info->ticker_msg, p, byte_len);
        
    }

    return 0;
}


int u8_byte_len(const char *utf8_buf, const int utf8_len) {
    int i;
    int j = 0;

    for (i = 0; i < utf8_len; i++) {
        if (utf8_buf[j] < 0x80) {
            j += 1;
        } else if (utf8_buf[j] < 0xE0) {
            j += 2;
        } else if (utf8_buf[j] < 0xF0) {
            j += 3;
        } else {
            j += 4;
        }
    }
    return j;
}

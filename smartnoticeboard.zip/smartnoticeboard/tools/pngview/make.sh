#!/usr/bin/env bash
cd /home/pi/piimage/tools/pngview
make
sudo rm -f /usr/local/bin/pngview
sudo cp /home/pi/piimage/tools/pngview/pngview /usr/local/bin/pngview
sudo chmod +x /usr/local/bin/pngview





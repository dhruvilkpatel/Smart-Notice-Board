
#ifndef LOADPNG_H
#define LOADPNG_H

#include <stdbool.h>

#include "image.h"

bool loadPng(IMAGE_T *image, const char *file);

#endif

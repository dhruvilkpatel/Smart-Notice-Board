pdate_uzbl(){
	echo "UZBL code base will be moved to commit : $1"

	cd /home/pi/uzbl
	sudo make uninstall
	sudo make clean

	git pull origin master
	git fetch --tags
	git checkout $1
	make
	sudo make install

	sudo rm -rf /usr/local/bin/uzbl
	sudo ln -s /usr/local/bin/uzbl-browser /usr/local/bin/uzbl
}

install_uzbl_git(){
	echo "uzbl repo not found, So installing uzbl ... "
	rm -rf /home/pi/uzbl
	cd /home/pi/
	git clone git://github.com/uzbl/uzbl.git
	cd uzbl
    git fetch --tags
	git checkout $1
	make
	sudo make install

    sudo rm -rf /usr/local/bin/uzbl
	sudo ln -s /usr/local/bin/uzbl-browser /usr/local/bin/uzbl
}

if [ -z $1 ];then
	COMMIT="tags/v0.9.0"
else
	COMMIT=$1
fi

if [ -d "/home/pi/uzbl" ];then
	update_uzbl $COMMIT
fi


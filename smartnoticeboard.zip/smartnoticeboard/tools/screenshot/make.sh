#!/usr/bin/env bash
cd /home/pi/piimage/tools/screenshot
sudo apt-get -y install libjpeg8-dev
make
sudo rm -f /usr/local/bin/screenshot
sudo cp  /home/pi/piimage/tools/screenshot/screenshot /usr/local/bin/screenshot
sudo chmod +x /usr/local/bin/screenshot

cd /home/pi/
sudo sed -i 's/.*http.get(API_VIDEO_INFO, params=params.*/\tres = http.get(API_VIDEO_INFO, params=params , headers=HLS_HEADERS)/' /usr/local/lib/python2.7/dist-packages/livestreamer/plugins/youtube.py
